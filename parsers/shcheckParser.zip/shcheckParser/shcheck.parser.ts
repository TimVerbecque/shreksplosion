import { createHmac } from 'crypto';
import { readFile } from 'fs/promises';
import { Parser } from './base.parser';

export class ShcheckParser extends Parser {
    public type(): string {
        return 'SHCHECK';
    }

    private ensureArray(val: object | object[]) {
        return Array.isArray(val) ? val : [val];
    }

    async parseFile(file: string, serverId: string, projectId: string, resultId: string) {
        const data = await readFile(file, 'utf8');
        const shcheckOutput = JSON.parse(data);
        const operations = [];

        const url = 'https://www.refracted.eu';
        const urlResult = shcheckOutput[url];
        if (urlResult && typeof urlResult === 'object') {
            operations.push([
                {
                    index: {
                        _index: `${serverId}_scan_results_${projectId}`,
                        _id: this.calculateFingerprint(url, shcheckOutput.time),
                    },
                },
                {
                    url,
                    result: urlResult,
                    '_result-id': resultId,
                },
            ]);
        }

        return operations;
    }

    private calculateFingerprint(url: string, time: string): string {
        const input = `${url}${time}`;
        const hasher = createHmac('sha256', 'fingerprint-key');
        
        return hasher.update(input).digest('base64');
    }
}
