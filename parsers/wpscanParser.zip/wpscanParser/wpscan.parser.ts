import { createHmac } from 'crypto';
import { readFile } from 'fs/promises';
import { Parser } from './base.parser';

export class WPScanParser extends Parser {
    public type(): string {
        return 'WPSCAN';
    }
    
    private ensureArray(val: object | object[]) {
        return Array.isArray(val) ? val : [val];
    }

    async parseFile(file: string, serverId: string, projectId: string, resultId: string) {
        const data = await readFile(file, 'utf8');
        const wpscanOutput = JSON.parse(data);
        const hosts = this.ensureArray(wpscanOutput);
        const operations = [];

        for (const host of hosts) {
            operations.push([
                {
                    index: {
                        _index: `${serverId}_scan_results_${projectId}`,
                        _id: this.calculateFingerprint(host),
                    },
                },
                {
                    ...host,
                    '_result-id': resultId,
                },
            ]);
        }

        return operations;
    }

    private calculateFingerprint(input: any): string {
        const url = input?.effective_url;
        const time = input?.start_time;
        const memory = input?.start_memory;
        const hasher = createHmac('sha256', 'fingerprint-key');

        return hasher.update(`${url}${time}${memory}`).digest('base64');
    }
}
