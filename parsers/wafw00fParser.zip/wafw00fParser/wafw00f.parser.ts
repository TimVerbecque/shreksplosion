import { createHmac } from 'crypto';
import { readFile } from 'fs/promises';
import { Parser } from './base.parser';

export class Wafw00fParser extends Parser {
    public type(): string {
        return 'WAFW00F';
    }
    
    private ensureArray(val: object | object[]) {
        return Array.isArray(val) ? val : [val];
    }

    async parseFile(file: string, serverId: string, projectId: string, resultId: string) {
        const data = await readFile(file, 'utf8');
        const whatweboutput = JSON.parse(data);
        const hosts = this.ensureArray(whatweboutput);
        const fingerprint = this.calculateFingerprint(hosts);

        const operations = [
            {
                index: {
                    _index: `${serverId}_scan_results_${projectId}`,
                    _id: fingerprint,
                },
            },
            ...whatweboutput.map((finding) => ({
                ...finding,
                '_result-id': resultId,
            })),
        ];

        return operations;
    }

    private calculateFingerprint(input: any): string {
        const url = input?.target;
        const time = input?.time;
        const hasher = createHmac('sha256', 'fingerprint-key');

        return hasher.update(`${url}${time}`).digest('base64');
    }
}
